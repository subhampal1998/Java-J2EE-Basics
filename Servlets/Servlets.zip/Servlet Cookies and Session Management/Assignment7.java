

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Assignment7
 */
@WebServlet("/Assignment7")
public class Assignment7 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	 private int c=0;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		session.setAttribute("session_id", ++c);
		Date dt = new Date(session.getCreationTime());
		SimpleDateFormat ft = new SimpleDateFormat("HH:mm:ssZ");
		out.println("Your session id is "+session.getId());
		out.print("<br/>");
		out.println("Your session creation time is "+ft.format(dt));
		out.print("<br/>");
		out.println("You have visited "+c+" times");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
