

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Assignment6
 */
@WebServlet("/Assignment6")
public class Assignment6 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		Cookie c=new Cookie("Subham","100");
		response.addCookie(c);
		Cookie c1=new Cookie("Sub","10");
		response.addCookie(c1);
		Cookie[] ck=request.getCookies();
		try{
			int l=ck.length;
			for(int i=0;i<l;i++)
			{
				String name=ck[i].getName();
				String value=ck[i].getValue();
				out.println("<tr>");
				out.println("<td>");
				out.println(name);
				out.println("</td>");
				out.println("<td>");
				out.println(value);
				out.println("</tr>");
			}
		}catch(Exception e){
			out.print("No cookies found !<br />"+"Error: "+e.getMessage());
		}
		
		
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
