

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import test.*;

/**
 * Servlet implementation class DBservlet
 */
@WebServlet("/DBservlet")
public class DBservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=Integer.parseInt(request.getParameter("id"));
		String name=(String)request.getParameter("name");
		String desig=(String)request.getParameter("designation");
		try {
			 Connection connection =   DatabaseConnection.initializeDatabase();
			 Statement smt= connection.createStatement();
			 
			 smt.executeUpdate("INSERT INTO emptable VALUES('"+id+"', '"+name+"', '"+desig+"')"); 
			 
			 
			 PrintWriter out = response.getWriter(); 
	         out.println("<html><body><b>Successfully Inserted"
	                        + "</b></body></html>"); 
	         
	         ResultSet st= smt.executeQuery("SELECT * FROM emptable");
	         while(st.next())
	         {
	        	 out.println(st.getInt("id"));
	        	 out.println(st.getString("name"));
	        	 out.println(st.getString("designation"));
	         }
	         }
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
