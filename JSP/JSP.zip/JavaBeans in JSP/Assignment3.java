

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Assignment3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String value=request.getParameter("num");
		int v=Integer.parseInt(value);
		if(v<10)
		{
			request.setAttribute("v", v);
			RequestDispatcher rd=request.getRequestDispatcher("Page1.jsp");
			rd.forward(request, response);
		}
		else if(v>10&&v<99)
		{
			request.setAttribute("v", v);
			RequestDispatcher rd=request.getRequestDispatcher("Page2.jsp");
			rd.forward(request, response);
		}
		else
		{
			request.setAttribute("v", v);
			RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
			rd.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
