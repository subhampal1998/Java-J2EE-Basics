package test;
import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.SQLException; 
  
 
public class DatabaseConnection { 
    public static Connection initializeDatabase() throws ClassNotFoundException
    { 
        try{
        String dbDriver = "oracle.jdbc.driver.OracleDriver"; 
        String dbURL = "jdbc:oracle:thin:@localhost:1521:orcl"; 
        String dbUsername = "scott"; 
        String dbPassword = "Wipro123"; 
  
        Class.forName(dbDriver); 
        Connection con = DriverManager.getConnection(dbURL,dbUsername,dbPassword); 
        
        	System.out.println( con.getMetaData().getDatabaseProductName());
        return con; 
        }
        catch(SQLException e)
        {
        	System.out.println(e.getMessage());
        	return null;
        }
        
    } 
}
